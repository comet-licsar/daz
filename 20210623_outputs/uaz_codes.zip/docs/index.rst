daz
===

This is toolkit described in https://www.essoar.org/doi/abs/10.1002/essoar.10511058.1 to process azimuth offsets (estimated within LiCSAR system) in order to acquire
precise N-S measurements of tectonics.
